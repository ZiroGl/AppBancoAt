package br.ulbra.appbanco;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegistrarActivity extends AppCompatActivity {
    EditText edtNome_registro,edtLogin_registro, edtPass_registro, edtPass2_registro;
    Button btnRegistrar_registro;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrar_pessoa);
        db = new DBHelper(this);

        edtNome_registro = (EditText)findViewById(R.id.edtNome_registro);
        edtLogin_registro = (EditText)findViewById(R.id.edtLogin_registro);
        edtPass_registro = (EditText)findViewById(R.id.edtPass_registro);
        edtPass2_registro = (EditText)findViewById(R.id.edtPass2_registro);


        btnRegistrar_registro = (Button)findViewById(R.id.btnRegistrar_registro);

        btnRegistrar_registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = edtLogin_registro.getText().toString();
                String pas1 = edtPass_registro.getText().toString();
                String pas2 = edtPass2_registro .getText().toString();
                if (userName.equals("")) {
                    Toast.makeText(RegistrarActivity.this, "Insira o LOGIN DO USUÁRIO", Toast.LENGTH_SHORT).show();
                } else if (pas1.equals("") || pas2.equals("")){
                    Toast.makeText(RegistrarActivity.this, "Insira a SENHA DO USUÁRIO", Toast.LENGTH_SHORT).show();
                }else if(!pas1.equals(pas2)){
                    Toast.makeText(RegistrarActivity.this, "As senhas não correspondem ao login do usuário", Toast.LENGTH_SHORT).show();
                }else{
                    long res = db.criarUtilizador(userName,pas1);
                    if(res>0){
//nesta parte você poderá chamar a tela principal do sistema autenticado
                        Toast.makeText(RegistrarActivity.this, "Resgistro OK",  Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(RegistrarActivity.this, "Senha inválida!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

}
